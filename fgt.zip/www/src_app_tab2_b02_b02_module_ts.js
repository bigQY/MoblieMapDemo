"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_b02_b02_module_ts"],{

/***/ 8540:
/*!************************************************!*\
  !*** ./src/app/tab2/b02/b02-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B02PageRoutingModule": () => (/* binding */ B02PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _b02_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b02.page */ 3751);




const routes = [
    {
        path: '',
        component: _b02_page__WEBPACK_IMPORTED_MODULE_0__.B02Page
    }
];
let B02PageRoutingModule = class B02PageRoutingModule {
};
B02PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], B02PageRoutingModule);



/***/ }),

/***/ 6866:
/*!****************************************!*\
  !*** ./src/app/tab2/b02/b02.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B02PageModule": () => (/* binding */ B02PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _b02_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b02-routing.module */ 8540);
/* harmony import */ var _b02_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b02.page */ 3751);







let B02PageModule = class B02PageModule {
};
B02PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _b02_routing_module__WEBPACK_IMPORTED_MODULE_0__.B02PageRoutingModule
        ],
        declarations: [_b02_page__WEBPACK_IMPORTED_MODULE_1__.B02Page]
    })
], B02PageModule);



/***/ }),

/***/ 3751:
/*!**************************************!*\
  !*** ./src/app/tab2/b02/b02.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B02Page": () => (/* binding */ B02Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _b02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b02.page.html?ngResource */ 1268);
/* harmony import */ var _b02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b02.page.scss?ngResource */ 6590);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);



/* eslint-disable @angular-eslint/component-selector */
/* eslint-disable @typescript-eslint/quotes */
/* eslint-disable curly */
/* eslint-disable @typescript-eslint/consistent-type-assertions */
/* eslint-disable @typescript-eslint/no-inferrable-types */
/* eslint-disable @angular-eslint/use-lifecycle-interface */
/* eslint-disable @typescript-eslint/member-ordering */


let B02Page = class B02Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.imgs = ['/assets/imges/logo.png', '/assets/imges/Mario.png', '/assets/imges/kitten1.jpg'];
        /** 用于控制表格第1行的跨列数 */
        this.colspanProperty = 2;
        /** p1、p2都是在b02.page.scss文件中定义的CSS类 */
        this.cssClass = ['p1', 'p2'];
    }
    ionViewDidLoad() {
        this.div1 = document.getElementById('div1');
        this.imgSrc = this.imgs[0];
        this.classProp = this.cssClass[0];
    }
    ngOnInit() {
        this.ionViewDidLoad();
    }
    //【单向绑定】启动定时器
    start() {
        //每隔1秒自动切换一次图片
        this.id1 = window.setInterval(() => {
            if (this.imgSrc === this.imgs[0]) {
                this.imgSrc = this.imgs[1];
            }
            else if (this.imgSrc === this.imgs[1]) {
                this.imgSrc = this.imgs[2];
            }
            else {
                this.imgSrc = this.imgs[0];
            }
        }, 1000);
        //每隔2秒自动切换一次CSS类名
        this.id2 = window.setInterval(() => {
            if (this.classProp === this.cssClass[0]) {
                //console.log("hello");
                //debugger;
                this.classProp = this.cssClass[1];
            }
            else {
                //debugger;
                this.classProp = this.cssClass[0];
            }
        }, 2000);
    }
    //【单向绑定】停止定时器
    stop() {
        if (this.id1 === undefined)
            return;
        clearInterval(this.id1);
        clearInterval(this.id2);
    }
    //【事件处理】切换div1的显示和隐藏
    switchDiv() {
        this.div1.hidden = !this.div1.hidden;
    }
};
B02Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
B02Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-b02',
        template: _b02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_b02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], B02Page);



/***/ }),

/***/ 6590:
/*!***************************************************!*\
  !*** ./src/app/tab2/b02/b02.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = ".p1 {\n  font-size: 14px;\n  color: red;\n}\n\n.p2 {\n  font-size: 25px;\n  color: green;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImIwMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBV0E7RUFDRSxlQUFBO0VBQ0EsVUFBQTtBQVZGOztBQWFBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7QUFWRiIsImZpbGUiOiJiMDIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gYXBwLWIwMiB7XHJcbi8vICAgLnAxIHtcclxuLy8gICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4vLyAgICAgICBjb2xvcjogcmVkO1xyXG4vLyAgIH1cclxuLy8gICAucDIge1xyXG4vLyAgICAgICBmb250LXNpemU6IDI1cHg7XHJcbi8vICAgICAgIGNvbG9yOiBncmVlbjtcclxuLy8gICB9XHJcbi8vIH1cclxuXHJcbi5wMSB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbi5wMiB7XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG4gIGNvbG9yOiBncmVlbjtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 1268:
/*!***************************************************!*\
  !*** ./src/app/tab2/b02/b02.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"返回\" defaultHerf=\"tabs/tab2\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>【B02】单向绑定</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content style=\"text-align: center;\">\n    <!-- 参数div1是引用div中用#前缀声明的变量名 -->\n    <ion-button (click)='start()'>启动定时器</ion-button>\n    <ion-button (click)='stop()'>停止定时器</ion-button>\n    <ion-button (click)='switchDiv()'>切换div的显示和隐藏</ion-button>\n    <hr>\n    <div id='div1' style=\"text-align: center;\">\n        <!-- 【中括号：单向绑定（仅目标绑定到源），此处目标是img元素的【src】特性，源是在TS中定义的【imgSrc】属性】 -->\n        <img [src]='imgSrc' style=\"width:50px;\">\n        <!-- 【单向绑定特例】attr绑定 -->\n        <table border='1'>\n            <tr>\n              <td>第1行第1列</td>\n              <!-- 这个是【单向绑定】的特例，colspanProperty是在TS中声明的属性，在TS中可根据情况控制该属性的值来改变这个colspan特性 -->\n                <td [attr.colspan]='colspanProperty'>第1行第2、3列</td>\n              <td>第1行第4列</td>\n            </tr>\n            <tr>\n                <td>第2行第1列</td>\n                <td>第2行第2列</td>\n                <td>第2行第3列</td>\n                <td>第2行第4列</td>\n            </tr>\n        </table>\n        <!-- 【单向绑定特例】CSS类绑定 -->\n        <p [class]='classProp'>哈哈，看我的颜色和字体大小变化</p>\n    </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_b02_b02_module_ts.js.map