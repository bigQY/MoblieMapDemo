"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_tab4_module_ts"],{

/***/ 5355:
/*!*********************************************!*\
  !*** ./src/app/tab4/tab4-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab4PageRoutingModule": () => (/* binding */ Tab4PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab4.page */ 3631);




const routes = [
    {
        path: '',
        component: _tab4_page__WEBPACK_IMPORTED_MODULE_0__.Tab4Page
    },
    {
        path: 'd01', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d01_d01_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d01/d01.module */ 7554)).then(m => m.D01PageModule)
    },
    {
        path: 'd02', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d02_d02_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d02/d02.module */ 5374)).then(m => m.D02PageModule)
    },
    {
        path: 'd03', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d03_d03_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d03/d03.module */ 9196)).then(m => m.D03PageModule)
    },
    {
        path: 'd04', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d04_d04_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d04/d04.module */ 4951)).then(m => m.D04PageModule)
    },
    {
        path: 'd05', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d05_d05_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d05/d05.module */ 9529)).then(m => m.D05PageModule)
    },
    {
        path: 'd06', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d06_d06_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d06/d06.module */ 8415)).then(m => m.D06PageModule)
    },
    {
        path: 'd07', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d07_d07_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d07/d07.module */ 9056)).then(m => m.D07PageModule)
    },
    {
        path: 'd08', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_d08_d08_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./d08/d08.module */ 5738)).then(m => m.D08PageModule)
    }
];
let Tab4PageRoutingModule = class Tab4PageRoutingModule {
};
Tab4PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Tab4PageRoutingModule);



/***/ }),

/***/ 2486:
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab4PageModule": () => (/* binding */ Tab4PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _tab4_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab4-routing.module */ 5355);
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab4.page */ 3631);







let Tab4PageModule = class Tab4PageModule {
};
Tab4PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _tab4_routing_module__WEBPACK_IMPORTED_MODULE_0__.Tab4PageRoutingModule
        ],
        declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_1__.Tab4Page]
    })
], Tab4PageModule);



/***/ }),

/***/ 3631:
/*!***********************************!*\
  !*** ./src/app/tab4/tab4.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab4Page": () => (/* binding */ Tab4Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _tab4_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab4.page.html?ngResource */ 9184);
/* harmony import */ var _tab4_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab4.page.scss?ngResource */ 7432);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let Tab4Page = class Tab4Page {
    constructor(nav) {
        this.nav = nav;
        var script = document.createElement("script");
        script.src = "https://api.map.baidu.com/api?v=3.0&ak=da1K4Mxg4LItgEhMy5h8k3ZbXzLzFb2I&callback=initialize";
        document.body.appendChild(script);
    }
    showPage1() {
        this.nav.navigateForward('/tabs/tab4/d01');
    }
    showPage2() {
        this.nav.navigateForward('/tabs/tab4/d02');
    }
    showPage3() {
        this.nav.navigateForward('/tabs/tab4/d03');
    }
    showPage4() {
        this.nav.navigateForward('/tabs/tab4/d04');
    }
    showPage5() {
        this.nav.navigateForward('/tabs/tab4/d05');
    }
    showPage6() {
        this.nav.navigateForward('/tabs/tab4/d06');
    }
    showPage7() {
        this.nav.navigateForward('/tabs/tab4/d07');
    }
    showPage8() {
        this.nav.navigateForward('/tabs/tab4/d08');
    }
};
Tab4Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
Tab4Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tab4',
        template: _tab4_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tab4_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab4Page);



/***/ }),

/***/ 7432:
/*!************************************************!*\
  !*** ./src/app/tab4/tab4.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWI0LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 9184:
/*!************************************************!*\
  !*** ./src/app/tab4/tab4.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n    <ion-toolbar>\n        <ion-title>BaiduMap </ion-title>\n    </ion-toolbar>\n</ion-header>\n<ion-content [fullscreen]=\"true\" padding>\n    <ion-list>\n        <ion-item>\n            <ion-button (click)=\"showPage1()\">D01-地图和控件</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage2()\">D02-覆盖物</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage3()\">D03-信息窗口</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage4()\">D04-标注</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage5()\">D05-全景图与地址解析</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage6()\">D06-定位</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage7()\">D07-公交查询与位置检索</ion-button>\n        </ion-item>\n        <ion-item>\n            <ion-button (click)=\"showPage8()\">D08-GPS导航</ion-button>\n        </ion-item>\n    </ion-list>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_tab4_module_ts.js.map