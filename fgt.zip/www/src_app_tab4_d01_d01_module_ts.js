"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d01_d01_module_ts"],{

/***/ 7020:
/*!************************************************!*\
  !*** ./src/app/tab4/d01/d01-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D01PageRoutingModule": () => (/* binding */ D01PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d01_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d01.page */ 5718);




const routes = [
    {
        path: '',
        component: _d01_page__WEBPACK_IMPORTED_MODULE_0__.D01Page
    }
];
let D01PageRoutingModule = class D01PageRoutingModule {
};
D01PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D01PageRoutingModule);



/***/ }),

/***/ 7554:
/*!****************************************!*\
  !*** ./src/app/tab4/d01/d01.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D01PageModule": () => (/* binding */ D01PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d01_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d01-routing.module */ 7020);
/* harmony import */ var _d01_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d01.page */ 5718);







let D01PageModule = class D01PageModule {
};
D01PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d01_routing_module__WEBPACK_IMPORTED_MODULE_0__.D01PageRoutingModule
        ],
        declarations: [_d01_page__WEBPACK_IMPORTED_MODULE_1__.D01Page]
    })
], D01PageModule);



/***/ }),

/***/ 5718:
/*!**************************************!*\
  !*** ./src/app/tab4/d01/d01.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D01Page": () => (/* binding */ D01Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d01.page.html?ngResource */ 181);
/* harmony import */ var _d01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d01.page.scss?ngResource */ 1663);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D01Page = class D01Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ionViewDidLoad() {
        this.isKaifeng = true;
    }
    ngOnInit() {
        this.ionViewDidLoad();
    }
    //显示基本的开封地图（Hello World）
    click1() {
        this.isKaifeng = true;
        // 创建百度地图API的Map实例
        let map = new BMap.Map('bdmap');
        //或者【构造底图时，关闭底图可点击功能（关闭poi检索）】：
        //let map = new BMap.Map("container", { enableMapClick: false });
        // 设置地图中心点坐标（河大计算机学院门前路上）
        let point = new BMap.Point(114.315, 34.821);
        // 初始化地图和地图级别
        map.centerAndZoom(point, 15);
        //开启鼠标滚轮缩放【默认不开启】
        map.enableScrollWheelZoom();
    }
    //切换【北京/开封】并显示带控件控制的北京或开封地图
    click2() {
        this.isKaifeng = !this.isKaifeng;
        let map = new BMap.Map("bdmap");
        if (this.isKaifeng) {
            map.centerAndZoom(new BMap.Point(114.315745, 34.824635), 11);
            map.setCurrentCity('开封'); //设置地图显示的城市
        }
        else {
            map.centerAndZoom(new BMap.Point(116.404, 39.915), 11); // 初始化地图,设置中心点坐标和地图级别
            map.setCurrentCity('北京');
        }
        //添加平移缩放控件
        map.addControl(new BMap.NavigationControl());
        //添加比例尺控件
        map.addControl(new BMap.ScaleControl());
        //添加缩略图控件
        map.addControl(new BMap.OverviewMapControl());
        //添加默认的地图类型控件
        map.addControl(new BMap.MapTypeControl());
        //或者【指定仅显示哪些地图类型控件】：
        // map.addControl(new BMap.MapTypeControl({
        //     mapTypes: [
        //         BMAP_NORMAL_MAP,
        //         BMAP_PERSPECTIVE_MAP,//目前百度还没有实现开封的三维图
        //         BMAP_HYBRID_MAP,
        //     ]
        // }));
        map.enableScrollWheelZoom(); //开启鼠标滚轮缩放
    }
};
D01Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
D01Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d01',
        template: _d01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D01Page);



/***/ }),

/***/ 1663:
/*!***************************************************!*\
  !*** ./src/app/tab4/d01/d01.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDEucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 181:
/*!***************************************************!*\
  !*** ./src/app/tab4/d01/d01.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D01】地图与控件</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <div style=\"position: fixed;z-index: 99999;\">\n        <ion-button round (click)='click1()' Size=\"small\">显示开封地图</ion-button>\n        <ion-button ion-button round (click)='click2()'  Size=\"small\">切换[开封/北京]</ion-button>\n    </div>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d01_d01_module_ts.js.map