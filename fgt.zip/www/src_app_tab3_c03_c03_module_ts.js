"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_c03_c03_module_ts"],{

/***/ 5798:
/*!************************************************!*\
  !*** ./src/app/tab3/c03/c03-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C03PageRoutingModule": () => (/* binding */ C03PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _c03_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c03.page */ 2004);




const routes = [
    {
        path: '',
        component: _c03_page__WEBPACK_IMPORTED_MODULE_0__.C03Page
    }
];
let C03PageRoutingModule = class C03PageRoutingModule {
};
C03PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], C03PageRoutingModule);



/***/ }),

/***/ 7483:
/*!****************************************!*\
  !*** ./src/app/tab3/c03/c03.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C03PageModule": () => (/* binding */ C03PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _c03_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c03-routing.module */ 5798);
/* harmony import */ var _c03_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c03.page */ 2004);







let C03PageModule = class C03PageModule {
};
C03PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c03_routing_module__WEBPACK_IMPORTED_MODULE_0__.C03PageRoutingModule
        ],
        declarations: [_c03_page__WEBPACK_IMPORTED_MODULE_1__.C03Page]
    })
], C03PageModule);



/***/ }),

/***/ 2004:
/*!**************************************!*\
  !*** ./src/app/tab3/c03/c03.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C03Page": () => (/* binding */ C03Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _c03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c03.page.html?ngResource */ 267);
/* harmony import */ var _c03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c03.page.scss?ngResource */ 7013);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1864);





let C03Page = class C03Page {
    constructor(alertCtrl, toastCtrl, navCtrl) {
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.navCtrl = navCtrl;
        this.resultMessage = '';
        this.radioOpen = true;
    }
    ngOnInit() {
    }
    showAlert() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            let alert = this.alertCtrl.create({
                header: '这是标题',
                subHeader: '这是子标题',
                buttons: ['确定']
            });
            (yield alert).present();
        });
    }
    showConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            let confirm = this.alertCtrl.create({
                header: '你确认要离开吗？',
                message: '数据尚未保存，如果此时离开，所有未保存的数据都会丢失！',
                buttons: [
                    {
                        text: '取消', handler: () => {
                            this.resultMessage = '【确认警告框】的结果：单击了取消按钮';
                        }
                    },
                    {
                        text: '确定', handler: () => {
                            this.resultMessage = '【确认警告框】的结果：单击了确认按钮';
                        }
                    }
                ]
            });
            (yield confirm).present();
        });
    }
    showPrompt() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            let prompt = this.alertCtrl.create({
                header: '登录',
                message: "请在下方输入你已经注册过的用户名。如果尚未注册，请先注册！",
                inputs: [
                    { name: 'userName', placeholder: '用户名' },
                ],
                buttons: [
                    {
                        text: '取消', handler: () => {
                            this.resultMessage = '【输入警告框】的结果：单击了取消按钮';
                        }
                    },
                    {
                        text: '确定', handler: (data) => {
                            this.resultMessage = '【输入警告框】中输入的用户名：' + data['userName'];
                        }
                    }
                ]
            });
            (yield prompt).present();
        });
    }
    showRadio() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.resultMessage = '';
            let alert = this.alertCtrl.create({
                header: "请选择颜色",
                inputs: [
                    {
                        type: "radio",
                        label: "红色",
                        value: "红色"
                    },
                    {
                        type: "radio",
                        label: "绿色",
                        value: "绿色",
                        checked: true
                    },
                    {
                        type: "radio",
                        label: "蓝色",
                        value: "蓝色",
                    }
                ],
                buttons: [
                    {
                        text: "取消",
                        handler: (data) => {
                            this.resultMessage = '【单选警告框】的结果：单击了【取消】';
                        }
                    },
                    {
                        text: "确定",
                        handler: (data) => {
                            this.radioOpen = false;
                            this.radioResult = data;
                            this.resultMessage = '【单选警告框】的选择结果：' + data;
                        }
                    }
                ]
            });
            (yield alert).present();
        });
    }
    showCheckbox() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.resultMessage = '';
            let alert = this.alertCtrl.create({
                header: "你参加过哪些项目？",
                inputs: [
                    {
                        type: "checkbox",
                        label: "足球",
                        value: "足球"
                    },
                    {
                        type: "checkbox",
                        label: "篮球",
                        value: "篮球"
                    },
                    {
                        type: "checkbox",
                        label: "排球",
                        value: "排球"
                    }
                ],
                buttons: [
                    {
                        text: "取消"
                    },
                    {
                        text: "确定",
                        handler: (data) => {
                            this.resultMessage = '【复选警告框】的结果：' + data;
                            this.checkboxOpen = false;
                            this.checkboxResult = data;
                        }
                    }
                ]
            });
            (yield alert).present();
        });
    }
    presentToast() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            let toast = this.toastCtrl.create({
                message: '数据保存成功！',
                duration: 3000,
                position: 'bottom' //可选值：'top'，middle'，'bottom'
            });
            (yield toast).present();
        });
    }
};
C03Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
C03Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-c03',
        template: _c03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_c03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], C03Page);



/***/ }),

/***/ 7013:
/*!***************************************************!*\
  !*** ./src/app/tab3/c03/c03.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjMDMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 267:
/*!***************************************************!*\
  !*** ./src/app/tab3/c03/c03.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab3\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【C03】alert与toast</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding style=\"text-align: center;\">\n    <ion-button (click)='showAlert()'>基本</ion-button>\n    <br>\n    <ion-button ion-button (click)='showConfirm()'>确认</ion-button>\n    <br>\n    <ion-button ion-button (click)='showPrompt()'>输入</ion-button>\n    <br>\n    <ion-button ion-button (click)='showRadio()'>单选</ion-button>\n    <br>\n    <ion-button ion-button (click)='showCheckbox()'>复选</ion-button>\n    <br>\n    <ion-button ion-button (click)='presentToast()'>信息</ion-button>\n    <hr>\n    <div [innerText]='resultMessage'></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_c03_c03_module_ts.js.map