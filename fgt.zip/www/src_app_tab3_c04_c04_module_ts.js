"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_c04_c04_module_ts"],{

/***/ 6109:
/*!************************************************!*\
  !*** ./src/app/tab3/c04/c04-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C04PageRoutingModule": () => (/* binding */ C04PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _c04_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c04.page */ 3723);




const routes = [
    {
        path: '',
        component: _c04_page__WEBPACK_IMPORTED_MODULE_0__.C04Page
    }
];
let C04PageRoutingModule = class C04PageRoutingModule {
};
C04PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], C04PageRoutingModule);



/***/ }),

/***/ 3586:
/*!****************************************!*\
  !*** ./src/app/tab3/c04/c04.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C04PageModule": () => (/* binding */ C04PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _c04_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c04-routing.module */ 6109);
/* harmony import */ var _c04_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c04.page */ 3723);







let C04PageModule = class C04PageModule {
};
C04PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c04_routing_module__WEBPACK_IMPORTED_MODULE_0__.C04PageRoutingModule
        ],
        declarations: [_c04_page__WEBPACK_IMPORTED_MODULE_1__.C04Page]
    })
], C04PageModule);



/***/ }),

/***/ 3723:
/*!**************************************!*\
  !*** ./src/app/tab3/c04/c04.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C04Page": () => (/* binding */ C04Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _c04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c04.page.html?ngResource */ 7212);
/* harmony import */ var _c04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c04.page.scss?ngResource */ 620);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let C04Page = class C04Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
};
C04Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
C04Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-c04',
        template: _c04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_c04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], C04Page);



/***/ }),

/***/ 620:
/*!***************************************************!*\
  !*** ./src/app/tab3/c04/c04.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjMDQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 7212:
/*!***************************************************!*\
  !*** ./src/app/tab3/c04/c04.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab3\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【C04】头像、卡片、徽章</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n    <ion-list>\n        <ion-list-header>今天</ion-list-header>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/kitten1.jpg\">\n            </ion-avatar>\n            <h3>猫三</h3>\n            <p>这个地方对我们来说不够大。</p>\n            <ion-note item-end>15:43</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/kitten2.jpg\">\n            </ion-avatar>\n            <h3>猫四</h3>\n            <p>我的眼大不大？</p>\n            <ion-note item-end>13:12</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/kitten3.jpg\">\n            </ion-avatar>\n            <h3>猫五</h3>\n            <p>我是你见过的最可爱的吗？</p>\n            <ion-note item-end>10:03</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/kitten4.jpg\">\n            </ion-avatar>\n            <h3>猫六</h3>\n            <p>你没把我变成灰狐狸。</p>\n            <ion-note item-end>5:47</ion-note>\n        </ion-item>\n    </ion-list>\n\n    <ion-list>\n        <ion-list-header>昨天</ion-list-header>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/puppy1.jpg\">\n            </ion-avatar>\n            <h3>狗三</h3>\n            <p>你听说过功夫吗？准备好吃猪排吧。</p>\n            <ion-note item-end>23:11</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/puppy2.jpg\">\n            </ion-avatar>\n            <h3>狗四</h3>\n            <p>我可能不是聪明的狗, 但我知道死是什么。</p>\n            <ion-note item-end>20:54</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/puppy3.jpg\">\n            </ion-avatar>\n            <h3>狗五</h3>\n            <p>你害怕吗？老实告诉我。</p>\n            <ion-note item-end>7:22</ion-note>\n        </ion-item>\n        <ion-item>\n            <ion-avatar item-start>\n                <img src=\"assets/imges/puppy4.jpg\">\n            </ion-avatar>\n            <h3>狗六</h3>\n            <p>哇呜。</p>\n            <ion-note item-end>2:08</ion-note>\n        </ion-item>\n    </ion-list>\n\n    <!-- card（卡片）与badge（徽章）基本用法 -->\n    <ion-card>\n        <img src=\"assets/imges/kitten2.jpg\" />\n        <ion-card-content>\n            <ion-card-title>猫四</ion-card-title>\n            <p>猫四的眼睛就是大！</p>\n        </ion-card-content>\n\n        <ion-item>\n            <ion-icon name='musical-notes' item-start style=\"color: #d03e84\"></ion-icon>\n            相册\n            <ion-badge item-end>9个</ion-badge>\n        </ion-item>\n\n        <ion-item>\n            <ion-icon name='logo-twitter' item-start style=\"color: #55acee\"></ion-icon>\n            关注\n            <ion-badge item-end>260人次</ion-badge>\n        </ion-item>\n\n    </ion-card>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_c04_c04_module_ts.js.map