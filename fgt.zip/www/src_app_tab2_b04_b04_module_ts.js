"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_b04_b04_module_ts"],{

/***/ 5541:
/*!************************************************!*\
  !*** ./src/app/tab2/b04/b04-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B04PageRoutingModule": () => (/* binding */ B04PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _b04_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b04.page */ 9040);




const routes = [
    {
        path: '',
        component: _b04_page__WEBPACK_IMPORTED_MODULE_0__.B04Page
    }
];
let B04PageRoutingModule = class B04PageRoutingModule {
};
B04PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], B04PageRoutingModule);



/***/ }),

/***/ 6010:
/*!****************************************!*\
  !*** ./src/app/tab2/b04/b04.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B04PageModule": () => (/* binding */ B04PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _b04_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b04-routing.module */ 5541);
/* harmony import */ var _b04_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b04.page */ 9040);







let B04PageModule = class B04PageModule {
};
B04PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _b04_routing_module__WEBPACK_IMPORTED_MODULE_0__.B04PageRoutingModule
        ],
        declarations: [_b04_page__WEBPACK_IMPORTED_MODULE_1__.B04Page]
    })
], B04PageModule);



/***/ }),

/***/ 9040:
/*!**************************************!*\
  !*** ./src/app/tab2/b04/b04.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B04Page": () => (/* binding */ B04Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _b04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b04.page.html?ngResource */ 4410);
/* harmony import */ var _b04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b04.page.scss?ngResource */ 1473);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);



/* eslint-disable @typescript-eslint/no-inferrable-types */
/* eslint-disable @typescript-eslint/member-ordering */


let B04Page = class B04Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.students = ['张三', '李四', '王五'];
        //age: number = 18;
        this.grade = 56;
    }
    ngOnInit() {
    }
};
B04Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
B04Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-b04',
        template: _b04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_b04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], B04Page);



/***/ }),

/***/ 1473:
/*!***************************************************!*\
  !*** ./src/app/tab2/b04/b04.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiMDQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4410:
/*!***************************************************!*\
  !*** ./src/app/tab2/b04/b04.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"返回\" defaultHerf=\"tabs/tab2\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>【B04】内置指令</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding >\n  <div style=\"margin: 10px;width: 90vw;\">\n    <p style='color:red;'>ngFor基本用法</p>\n    <!-- 显示b04.ts中定义的students数组中的所有元素 -->\n    <p>所有学生：</p>\n    <div *ngFor=\"let student of students\">\n        {{student}}\n        <br>\n    </div>\n\n    <p style='color:red;'>ngIf基本用法</p>\n    <!-- 如果b04.ts中存在age属性，就显示它，否则移除这个div元素 -->\n    <div *ngIf='age'>\n        张三的年龄为：{{age}}\n    </div>\n    <!-- 如果b04.ts中存在grade属性，就显示它，否则移除这个div元素 -->\n    <div *ngIf='grade'>\n         张三的成绩为：{{grade}}\n    </div>\n  </div>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_b04_b04_module_ts.js.map