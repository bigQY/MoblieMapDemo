"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_a01_a01_module_ts"],{

/***/ 5931:
/*!*****************************************!*\
  !*** ./src/app/providers/Helloworld.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Student": () => (/* binding */ Student),
/* harmony export */   "greeter": () => (/* binding */ greeter)
/* harmony export */ });
class Student {
    constructor(name, welcomeInfo) {
        this.name = name;
        this.welcomeInfo = welcomeInfo;
        this.message = name + '、n' + welcomeInfo;
    }
}
// eslint-disable-next-line prefer-arrow/prefer-arrow-functions
function greeter(person) {
    return 'Hello, ' + person.name + ' ' + person.welcomeInfo;
}


/***/ }),

/***/ 9980:
/*!************************************************!*\
  !*** ./src/app/tab1/a01/a01-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A01PageRoutingModule": () => (/* binding */ A01PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _a01_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a01.page */ 4745);




const routes = [
    {
        path: '',
        component: _a01_page__WEBPACK_IMPORTED_MODULE_0__.A01Page
    }
];
let A01PageRoutingModule = class A01PageRoutingModule {
};
A01PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], A01PageRoutingModule);



/***/ }),

/***/ 6000:
/*!****************************************!*\
  !*** ./src/app/tab1/a01/a01.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A01PageModule": () => (/* binding */ A01PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _a01_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a01-routing.module */ 9980);
/* harmony import */ var _a01_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a01.page */ 4745);







let A01PageModule = class A01PageModule {
};
A01PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _a01_routing_module__WEBPACK_IMPORTED_MODULE_0__.A01PageRoutingModule
        ],
        declarations: [_a01_page__WEBPACK_IMPORTED_MODULE_1__.A01Page]
    })
], A01PageModule);



/***/ }),

/***/ 4745:
/*!**************************************!*\
  !*** ./src/app/tab1/a01/a01.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A01Page": () => (/* binding */ A01Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _a01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a01.page.html?ngResource */ 5542);
/* harmony import */ var _a01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a01.page.scss?ngResource */ 2258);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_providers_Helloworld__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/Helloworld */ 5931);






let A01Page = class A01Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ionViewDidLoad() {
        this.myDiv = document.getElementById('mydiv');
    }
    ngOnInit() {
        this.ionViewDidLoad();
    }
    // hello world
    click1() {
        var user1 = { name: '张三', welcomeInfo: '您好！' };
        var user2 = new src_app_providers_Helloworld__WEBPACK_IMPORTED_MODULE_2__.Student('李四', '欢迎你！');
        this.myDiv.innerText = (0,src_app_providers_Helloworld__WEBPACK_IMPORTED_MODULE_2__.greeter)(user1) + '\n' + user2.message;
    }
    // let和var的区别
    click2() {
        let mydiv = this.myDiv;
        mydiv.innerText = 'var和let语法相同，其实两者的区别并不是在语法上，而是在语义上！\n';
        for (var i = 0; i < 5; i++) {
            mydiv.innerText += 'a' + i + '\n';
            var age1 = 23;
        }
        // 注意：i和age1都是在循环体内声明的，但是循环结束后仍然可用！
        mydiv.innerText += 'i=' + i + '，age=' + age1 + '\n\n';
        //  解决var全局污染的办法很简单，只需要将所有var全部都改为let就行了
        for (let j = 0; j < 5; j++) {
            mydiv.innerText += 'b' + j + '\n';
        }
    }
    click3() {
        this.myDiv.innerText = '\n想一想，为什么这段代码执行的结果和预期的不一致？\n\n';
        var that = this;
        for (var i = 0; i < 10; i++) {
            // 等待200毫秒，然后开始执行function()函数
            // tslint:disable-next-line: only-arrow-functions
            setTimeout(function () {
                that.myDiv.innerText += i + '\n';
            }, 200);
        }
    }
    // 前面都是为了说明问题，这个才是正确的写法
    click4() {
        this.myDiv.innerText = '';
        for (let i = 0; i < 10; i++) {
            setTimeout(() => {
                this.myDiv.innerText += i + '\n';
            }, 200);
        }
    }
};
A01Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
A01Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-a01',
        template: _a01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_a01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], A01Page);



/***/ }),

/***/ 2258:
/*!***************************************************!*\
  !*** ./src/app/tab1/a01/a01.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhMDEucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 5542:
/*!***************************************************!*\
  !*** ./src/app/tab1/a01/a01.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/tab1\" text=\"返回\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>a01</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <div>\n    <ion-button color=\"primary\" (click)='click1()'>1-1 Hello World</ion-button>\n    <br>\n    <ion-button color=\"primary\" (click)='click2()'>1-2 var和let的区别</ion-button>\n    <br>\n    <ion-button color=\"primary\" (click)='click3()'>1-3 var的问题示例</ion-button>\n    <br>\n    <ion-button color=\"primary\" (click)='click4()'>1-4 let消除var很多bug</ion-button>\n  </div>\n  <br/>\n  <div id='mydiv'></div>\n</ion-content>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_a01_a01_module_ts.js.map