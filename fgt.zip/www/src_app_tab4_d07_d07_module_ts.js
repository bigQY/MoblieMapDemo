"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d07_d07_module_ts"],{

/***/ 1216:
/*!************************************************!*\
  !*** ./src/app/tab4/d07/d07-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D07PageRoutingModule": () => (/* binding */ D07PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d07_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d07.page */ 8101);




const routes = [
    {
        path: '',
        component: _d07_page__WEBPACK_IMPORTED_MODULE_0__.D07Page
    }
];
let D07PageRoutingModule = class D07PageRoutingModule {
};
D07PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D07PageRoutingModule);



/***/ }),

/***/ 9056:
/*!****************************************!*\
  !*** ./src/app/tab4/d07/d07.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D07PageModule": () => (/* binding */ D07PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d07_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d07-routing.module */ 1216);
/* harmony import */ var _d07_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d07.page */ 8101);







let D07PageModule = class D07PageModule {
};
D07PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d07_routing_module__WEBPACK_IMPORTED_MODULE_0__.D07PageRoutingModule
        ],
        declarations: [_d07_page__WEBPACK_IMPORTED_MODULE_1__.D07Page]
    })
], D07PageModule);



/***/ }),

/***/ 8101:
/*!**************************************!*\
  !*** ./src/app/tab4/d07/d07.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D07Page": () => (/* binding */ D07Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d07_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d07.page.html?ngResource */ 730);
/* harmony import */ var _d07_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d07.page.scss?ngResource */ 3329);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D07Page = class D07Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.tip = ''; //被div的innerHTML单向绑定的目标
    }
    ngOnInit() {
    }
    //公交线路查询
    click1() {
        this.tip = '查公交线路：查询跨城公交的线路。';
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 14);
        let transit = new BMap.TransitRoute(map, {
            renderOptions: {
                map: map,
                autoViewport: true
            },
            // 配置跨城公交的换成策略为优先出发早
            intercityPolicy: BMAP_INTERCITY_POLICY_EARLY_START,
            // 配置跨城公交的交通方式策略为飞机优先
            transitTypePolicy: BMAP_TRANSIT_TYPE_POLICY_AIRPLANE
        });
        let start = new BMap.Point(116.310791, 40.003419);
        let end = new BMap.Point(121.490546, 31.233585);
        transit.search(start, end);
    }
    //根据关键字本地搜索
    click2() {
        this.tip = '查景点：返回北京市“景点”关键字的检索结果，并展示在地图上。';
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 11);
        let local = new BMap.LocalSearch(map, {
            renderOptions: { map: map }
        });
        local.search("景点");
    }
    //圆形区域检索
    click3() {
        this.tip = '查餐馆：返回北京市圆形区域范围内“餐馆”的检索结果，并展示在地图上。';
        let map = new BMap.Map("bdmap"); // 创建Map实例
        let mPoint = new BMap.Point(116.404, 39.915);
        map.enableScrollWheelZoom();
        map.centerAndZoom(mPoint, 15);
        let circle = new BMap.Circle(mPoint, 1000, { fillColor: "blue", strokeWeight: 1, fillOpacity: 0.3, strokeOpacity: 0.3 });
        map.addOverlay(circle);
        let local = new BMap.LocalSearch(map, {
            renderOptions: {
                map: map,
                panel: "r-result",
                autoViewport: false
            }
        });
        local.searchNearby('餐馆', mPoint, 1000);
    }
    //显示详细检索结果
    click4() {
        this.tip = '查餐饮：显示以某个点为中心的【餐饮】检索结果，并在地图的下方显示所有查询结果的详细信息。';
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 11);
        let local = new BMap.LocalSearch(map, {
            renderOptions: { map: map, panel: "r-result" }
        });
        local.search("餐饮");
    }
};
D07Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
D07Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d07',
        template: _d07_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d07_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D07Page);



/***/ }),

/***/ 3329:
/*!***************************************************!*\
  !*** ./src/app/tab4/d07/d07.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDcucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 730:
/*!***************************************************!*\
  !*** ./src/app/tab4/d07/d07.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D07】检索与计算</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n    <div  style=\"position: fixed;z-index: 99999;\">\n        <ion-button size=\"small\" (click)='click1()'>查公交线路</ion-button>\n        <ion-button size=\"small\" (click)='click2()'>查景点</ion-button>\n        <ion-button size=\"small\" (click)='click3()'>查餐馆</ion-button>\n        <ion-button size=\"small\" (click)='click4()'>查餐饮</ion-button>\n    </div>\n    <hr>\n    <div [innerHTML]='tip' style='color:red;margin-top: 30px;'></div>\n    <hr>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n    <div id=\"r-result\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d07_d07_module_ts.js.map