"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d03_d03_module_ts"],{

/***/ 2252:
/*!************************************************!*\
  !*** ./src/app/tab4/d03/d03-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D03PageRoutingModule": () => (/* binding */ D03PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d03_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d03.page */ 9010);




const routes = [
    {
        path: '',
        component: _d03_page__WEBPACK_IMPORTED_MODULE_0__.D03Page
    }
];
let D03PageRoutingModule = class D03PageRoutingModule {
};
D03PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D03PageRoutingModule);



/***/ }),

/***/ 9196:
/*!****************************************!*\
  !*** ./src/app/tab4/d03/d03.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D03PageModule": () => (/* binding */ D03PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d03_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d03-routing.module */ 2252);
/* harmony import */ var _d03_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d03.page */ 9010);







let D03PageModule = class D03PageModule {
};
D03PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d03_routing_module__WEBPACK_IMPORTED_MODULE_0__.D03PageRoutingModule
        ],
        declarations: [_d03_page__WEBPACK_IMPORTED_MODULE_1__.D03Page]
    })
], D03PageModule);



/***/ }),

/***/ 9010:
/*!**************************************!*\
  !*** ./src/app/tab4/d03/d03.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D03Page": () => (/* binding */ D03Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d03.page.html?ngResource */ 6702);
/* harmony import */ var _d03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d03.page.scss?ngResource */ 6017);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D03Page = class D03Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.tip = ''; //被div的innerText单向绑定的目标
    }
    ngOnInit() {
    }
    //添加纯文字的信息窗口【点击标注点，可查看由纯文本构成的简单型信息窗口】
    click1() {
        this.tip = '提示：单击红色标注点，可弹出文字信息窗口。在红色标注点外的其他地方单击，可取消窗口。';
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.417854, 39.921988);
        let marker = new BMap.Marker(point); // 创建标注
        map.addOverlay(marker); // 将标注添加到地图中
        map.centerAndZoom(point, 15);
        let infoWindow = new BMap.InfoWindow("地址：北京市东城区王府井大街88号乐天银泰百货八层", {
            width: 220,
            height: 100,
            title: "海底捞王府井店",
            enableMessage: true,
            message: "亲耐滴，晚上一起吃个饭吧？戳下面的链接看下地址喔~"
        });
        marker.addEventListener("click", () => {
            marker.openInfoWindow(infoWindow); //开启信息窗口
        });
    }
    //添加图文组合的信息窗口【点击标注点，可查看由文本，图片构成的复杂型信息窗口】
    click2() {
        this.tip = '提示：单击红色标注点，可弹出由文本和图片构成的信息窗口。在红色标注点外的其他地方单击，可取消窗口。';
        //注意是反单引号
        let sContent = `<div>
      <h4 style="margin:0 0 5px 0;padding:0.2em 0">天安门</h4>
      <img style="float:right;margin:4px" id="imgDemo"
           src="/assets/imges/TianAnMen.jpg" width="139" height="104" title="天安门"/>
      <p style="margin:0;line-height:1.5;font-size:13px;text-indent:2em">
         天安门坐落在中国北京市中心,故宫的南侧,与天安门广场隔长安街相望,是清朝皇城的大门。
      </p>
      </div>`;
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.404, 39.915);
        let marker = new BMap.Marker(point);
        let infoWindow = new BMap.InfoWindow(sContent); // 创建信息窗口对象
        map.centerAndZoom(point, 15);
        map.addOverlay(marker);
        marker.addEventListener("click", () => {
            marker.openInfoWindow(infoWindow);
            //图片加载完毕重绘infowindow
            document.getElementById('imgDemo').onload = () => {
                infoWindow.redraw(); //防止在网速较慢图片未加载时，生成的信息框高度比图片的总高度小，导致图片部分被隐藏
            };
        });
    }
    //给多个点添加信息窗口【点击标注点，可查看由纯文本构成的简单型信息窗口】
    click3() {
        this.tip = '提示：单击某个红色标注点，可弹出对应的文字信息窗口。在红色标注点外的其他地方单击，可取消窗口。';
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.417854, 39.921988), 15);
        let data_info = [
            [116.417854, 39.921988, "地址：北京市东城区王府井大街88号乐天银泰百货八层"],
            [116.406605, 39.921585, "地址：北京市东城区东华门大街"],
            [116.412222, 39.912345, "地址：北京市东城区正义路甲5号"]
        ];
        let opts = {
            width: 250,
            height: 80,
            title: "信息窗口",
            enableMessage: true //设置允许信息窗发送短息
        };
        let openInfo = (content, e) => {
            let p = e.target;
            let point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
            let infoWindow = new BMap.InfoWindow(content, opts); // 创建信息窗口对象
            map.openInfoWindow(infoWindow, point); //开启信息窗口
        };
        let addClickHandler = (content, marker) => {
            marker.addEventListener("click", (e) => {
                openInfo(content, e);
            });
        };
        for (let i = 0; i < data_info.length; i++) {
            let marker = new BMap.Marker(new BMap.Point(data_info[i][0], data_info[i][1])); // 创建标注
            let content = data_info[i][2];
            map.addOverlay(marker); // 将标注添加到地图中
            addClickHandler(content, marker);
        }
    }
    //获取信息窗口的内容
    click4() {
        this.tip = '此例子演示如何自动弹出信息窗口。';
        let sContent = "天安门坐落在中国北京市中心,故宫的南侧,与天安门广场隔长安街相望,是清朝皇城的大门。";
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.404, 39.915);
        map.centerAndZoom(point, 15);
        let infoWindow = new BMap.InfoWindow(sContent); // 创建信息窗口对象
        map.openInfoWindow(infoWindow, point); //开启信息窗口
    }
};
D03Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
D03Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d03',
        template: _d03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D03Page);



/***/ }),

/***/ 6017:
/*!***************************************************!*\
  !*** ./src/app/tab4/d03/d03.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 6702:
/*!***************************************************!*\
  !*** ./src/app/tab4/d03/d03.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D03】信息窗口</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding>\n    <div  style=\"position: fixed;z-index: 99999;\">\n        <ion-button size=\"small\" (click)='click1()'>文字</ion-button>\n        <ion-button size=\"small\" (click)='click2()'>图文</ion-button>\n        <ion-button size=\"small\" (click)='click3()'>多点</ion-button>\n        <ion-button size=\"small\" (click)='click4()'>获取窗口信息</ion-button>\n    </div>\n    <hr>\n    <br>\n    <div [innerText]='tip' style=\"color:red;\"></div>\n    <hr>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d03_d03_module_ts.js.map