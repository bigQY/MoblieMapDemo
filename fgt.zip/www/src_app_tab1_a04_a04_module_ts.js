"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_a04_a04_module_ts"],{

/***/ 8271:
/*!************************************************!*\
  !*** ./src/app/tab1/a04/a04-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A04PageRoutingModule": () => (/* binding */ A04PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _a04_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a04.page */ 5421);




const routes = [
    {
        path: '',
        component: _a04_page__WEBPACK_IMPORTED_MODULE_0__.A04Page
    }
];
let A04PageRoutingModule = class A04PageRoutingModule {
};
A04PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], A04PageRoutingModule);



/***/ }),

/***/ 5986:
/*!****************************************!*\
  !*** ./src/app/tab1/a04/a04.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A04PageModule": () => (/* binding */ A04PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _a04_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a04-routing.module */ 8271);
/* harmony import */ var _a04_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a04.page */ 5421);







let A04PageModule = class A04PageModule {
};
A04PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _a04_routing_module__WEBPACK_IMPORTED_MODULE_0__.A04PageRoutingModule
        ],
        declarations: [_a04_page__WEBPACK_IMPORTED_MODULE_1__.A04Page]
    })
], A04PageModule);



/***/ }),

/***/ 5421:
/*!**************************************!*\
  !*** ./src/app/tab1/a04/a04.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A04Page": () => (/* binding */ A04Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _a04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a04.page.html?ngResource */ 7992);
/* harmony import */ var _a04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a04.page.scss?ngResource */ 481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);




let A04Page = class A04Page {
    constructor() {
    }
    ngOnInit() {
        this.ionViewDidLoad();
    }
    ionViewDidLoad() {
        this.myDiv = document.getElementById('mydiv');
        this.myDiv.innerText = '此处显示单击按钮后输出的结果';
        this.click1();
    }
    //JavaScript的写法
    click1() {
        this.myDiv.innerHTML = '<p>JavaScript：很多代码都像瞎子摸象似的</p>';
        //JavaScript的命名函数
        function add(x, y) {
            return x + y;
        }
        //JavaScript的匿名函数【Anonymous function】
        var myAdd = function (x, y, z) { return x + y + z; };
        var i = 5, j = 10, k = 10;
        this.myDiv.innerHTML += '<p>' +
            'i + j = ' + add(i, j) + '<br>' +
            'i + j + z = ' + myAdd(i, j, k) + '</p>';
    }
    //TypeScript的写法
    click2() {
        this.myDiv.innerHTML = '<p>TypeScript：类型明确、不易出错</p>';
        let add = (x, y) => {
            return x + y;
        };
        let myAdd = (x, y, z) => {
            return x + y + z;
        };
        let i = 5, j = 10, k = 10;
        this.myDiv.innerHTML += `<p>
          i + j = ${add(i, j)}<br>
          i + j + z = ${myAdd(i, j, k)}
      </p>`;
    }
};
A04Page.ctorParameters = () => [];
A04Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-a04',
        template: _a04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_a04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], A04Page);



/***/ }),

/***/ 481:
/*!***************************************************!*\
  !*** ./src/app/tab1/a04/a04.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhMDQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 7992:
/*!***************************************************!*\
  !*** ./src/app/tab1/a04/a04.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/tab1\" text=\"返回\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>a04</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <ion-toolbar>\n    <ion-segment value=\"data\">\n      <ion-segment-button value=\"data\" (click)='click1()'>\n        JavaScript的用法\n      </ion-segment-button>\n      <ion-segment-button value=\"array\" (click)='click2()'>\n        TypeScript的用法\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n  <br/>\n  <div id='mydiv'></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_a04_a04_module_ts.js.map