"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d05_d05_module_ts"],{

/***/ 1070:
/*!*******************************************!*\
  !*** ./src/app/providers/bdmap-common.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Henu": () => (/* binding */ Henu),
/* harmony export */   "HenuJSJXY": () => (/* binding */ HenuJSJXY),
/* harmony export */   "KFBZ": () => (/* binding */ KFBZ),
/* harmony export */   "BeiJing": () => (/* binding */ BeiJing)
/* harmony export */ });
/** 河南大学金明校区中心点 */
const Henu = {
    /** 经度【河南大学】 */
    lng: 114.314961,
    /** 纬度【河南大学】 */
    lat: 34.823363
};
/** 河南大学计算机学院门前中心点 */
const HenuJSJXY = {
    /** 经度【河南大学】 */
    lng: 114.315745,
    /** 纬度【河南大学】 */
    lat: 34.824635
};
/** 开封北站中心点 */
const KFBZ = {
    /** 经度【开封北站】 */
    lng: 114.267704,
    /** 纬度【开封北站】 */
    lat: 34.845826
};
/** 北京 */
const BeiJing = {
    /** 经度【北京市】 */
    B1_Lng: 116.404,
    /** 纬度【北京市】 */
    B1_Lat: 39.915,
    /** 经度【北京市海淀区】 */
    B2_Lng: 116.331398,
    /** 纬度【北京市海淀区】 */
    B2_Lat: 39.897445
};


/***/ }),

/***/ 3035:
/*!************************************************!*\
  !*** ./src/app/tab4/d05/d05-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D05PageRoutingModule": () => (/* binding */ D05PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d05_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d05.page */ 5995);




const routes = [
    {
        path: '',
        component: _d05_page__WEBPACK_IMPORTED_MODULE_0__.D05Page
    }
];
let D05PageRoutingModule = class D05PageRoutingModule {
};
D05PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D05PageRoutingModule);



/***/ }),

/***/ 9529:
/*!****************************************!*\
  !*** ./src/app/tab4/d05/d05.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D05PageModule": () => (/* binding */ D05PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d05_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d05-routing.module */ 3035);
/* harmony import */ var _d05_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d05.page */ 5995);







let D05PageModule = class D05PageModule {
};
D05PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d05_routing_module__WEBPACK_IMPORTED_MODULE_0__.D05PageRoutingModule
        ],
        declarations: [_d05_page__WEBPACK_IMPORTED_MODULE_1__.D05Page]
    })
], D05PageModule);



/***/ }),

/***/ 5995:
/*!**************************************!*\
  !*** ./src/app/tab4/d05/d05.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D05Page": () => (/* binding */ D05Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d05_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d05.page.html?ngResource */ 1219);
/* harmony import */ var _d05_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d05.page.scss?ngResource */ 3324);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_providers_bdmap_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/bdmap-common */ 1070);






let D05Page = class D05Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
    click1() {
        let map = new BMap.Map('bdmap');
        map.centerAndZoom(new BMap.Point(114.315745, 34.824635), 12);
        map.addControl(new BMap.NavigationControl());
        let stCtrl = new BMap.PanoramaControl(); //构造全景控件
        stCtrl.setOffset(new BMap.Size(20, 20));
        map.addControl(stCtrl); //添加全景控件
    }
    //正向地址解析（根据名称得到坐标）
    click2() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(src_app_providers_bdmap_common__WEBPACK_IMPORTED_MODULE_2__.BeiJing.B2_Lng, src_app_providers_bdmap_common__WEBPACK_IMPORTED_MODULE_2__.BeiJing.B2_Lat);
        map.centerAndZoom(point, 12);
        // 创建地址解析器实例
        let myGeo = new BMap.Geocoder();
        let address = "北京市海淀区上地10街";
        // 将地址解析结果显示在地图上,并调整地图视野
        myGeo.getPoint(address, (p) => {
            if (p) {
                map.centerAndZoom(p, 16);
                let marker = new BMap.Marker(p);
                map.addOverlay(marker);
                let text = address + '：' + p.lng + '，' + p.lat;
                marker.setLabel(new BMap.Label(text, {
                    offset: new BMap.Size(-110, -20)
                }));
            }
            else {
                alert("您选择的地址没有解析到结果!");
            }
        }, "北京市");
    }
    //逆向地址解析（根据坐标得到名称）
    click3() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(src_app_providers_bdmap_common__WEBPACK_IMPORTED_MODULE_2__.BeiJing.B2_Lng, src_app_providers_bdmap_common__WEBPACK_IMPORTED_MODULE_2__.BeiJing.B2_Lat);
        map.centerAndZoom(point, 12);
        let geoc = new BMap.Geocoder();
        map.addEventListener("click", (e) => {
            let pt = e.point;
            geoc.getLocation(pt, (rs) => {
                let marker = new BMap.Marker(pt);
                map.addOverlay(marker);
                let c = rs.addressComponents;
                let s = `${c.province},${c.city},${c.district},${c.street},${c.streetNumber}`;
                marker.setLabel(new BMap.Label(s, {
                    offset: new BMap.Size(-10, -20)
                }));
            });
        });
    }
};
D05Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
D05Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-d05',
        template: _d05_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d05_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D05Page);



/***/ }),

/***/ 3324:
/*!***************************************************!*\
  !*** ./src/app/tab4/d05/d05.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDUucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 1219:
/*!***************************************************!*\
  !*** ./src/app/tab4/d05/d05.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D05】全景图与地址解析</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <div  style=\"position: fixed;z-index: 99999;\">\n        <ion-button size=\"small\" (click)='click1()'>全景图</ion-button>\n        <ion-button size=\"small\" (click)='click2()'>地址解析</ion-button>\n        <ion-button size=\"small\" (click)='click3()'>逆地址解析</ion-button>\n    </div>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d05_d05_module_ts.js.map