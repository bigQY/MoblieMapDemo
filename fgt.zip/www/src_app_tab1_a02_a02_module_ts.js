"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_a02_a02_module_ts"],{

/***/ 1787:
/*!************************************************!*\
  !*** ./src/app/tab1/a02/a02-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A02PageRoutingModule": () => (/* binding */ A02PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _a02_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a02.page */ 6777);




const routes = [
    {
        path: '',
        component: _a02_page__WEBPACK_IMPORTED_MODULE_0__.A02Page
    }
];
let A02PageRoutingModule = class A02PageRoutingModule {
};
A02PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], A02PageRoutingModule);



/***/ }),

/***/ 6391:
/*!****************************************!*\
  !*** ./src/app/tab1/a02/a02.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A02PageModule": () => (/* binding */ A02PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _a02_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a02-routing.module */ 1787);
/* harmony import */ var _a02_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a02.page */ 6777);







let A02PageModule = class A02PageModule {
};
A02PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _a02_routing_module__WEBPACK_IMPORTED_MODULE_0__.A02PageRoutingModule
        ],
        declarations: [_a02_page__WEBPACK_IMPORTED_MODULE_1__.A02Page]
    })
], A02PageModule);



/***/ }),

/***/ 6777:
/*!**************************************!*\
  !*** ./src/app/tab1/a02/a02.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A02Page": () => (/* binding */ A02Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _a02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a02.page.html?ngResource */ 4394);
/* harmony import */ var _a02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a02.page.scss?ngResource */ 1225);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);




let A02Page = class A02Page {
    constructor() { }
    ngOnInit() {
        this.myDiv = document.getElementById('mydiv');
        this.click1();
    }
    // 基本数据类型
    click1() {
        const myDiv = this.myDiv;
        myDiv.innerHTML = '1. 基本数据类型';
        //字符串
        const color = 'bule';
        myDiv.innerHTML += 'color的值为：' + color + '<br>';
        // (1)反单引号字符串(可跨多行)
        //(2)反单引号字符串内的$符号(称为模板字符串)与C#的格式化字符串用法相似
        const name = 'TypeScript';
        myDiv.innerHTML += `字符串 "${name}" 包含“${name.length}”个字符<br>`;
        //boolean:布尔型
        let isDone = false;
        myDiv.innerHTML += `isDone的类型是${typeof isDone},值为${isDone}<br>`;
        //number:浮点数类型
        let decimal = 6; //10进制
        let hex = 0xf00d; //十六进制:前缀0x
        let binary = 0b1010; //二进制， 前缀0b
        let octal = 0o744; //八进制:前缀0o
        myDiv.innerHTML += `<p>
    变量decimal[6]的值为: ${decimal}<br/>
    变量hex[0xfo0d]的十进制值为: ${hex}<br/>
    变量binary[0b1010] 的十进制值为: ${binary}<br/>
    变量octal[00744]的十进制值为: ${octal}<br/>
    </p>`;
        //any:任意类型
        let a;
        myDiv.innerHTML += `<p>a的类型是${typeof a}<br/></p>`;
        //特殊类型: null、 undefined
        let n = null;
        let u = undefined;
        myDiv.innerHTML += `<p>n的类型是${typeof n}, 值是${a}<br/>u的类型是${typeof u},值是${u}</p>`;
    }
    // 数组
    click2() {
        let myDiv = this.myDiv;
        myDiv.innerHTML = '2、数组<hr/>';
        let list = [1, 2, 3];
        myDiv.innerHTML += '数组list 的值为: ';
        list.forEach((n) => {
            myDiv.innerHTML += n + ' ';
        });
        myDiv.innerHTML += '<br/>';
    }
    //元组
    click3() {
        let myDiv = this.myDiv;
        myDiv.innerHTML = '3、元组<hr/>';
        //[简单例子]let x: [string, number] = ["hello", 10];
        //[实用例子]下面数组y中的每个元素都是一个元组:
        let y = [
            ["key1", 10],
            ["key2", 20],
        ];
        let s = '';
        for (let i = 0; i < y.length; i++) {
            s += `${y[i][0]}, ${y[i][1]}<br/>`;
        }
        myDiv.innerHTML += `数组y的值为: <br/>${s}`;
    }
};
A02Page.ctorParameters = () => [];
A02Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-a02',
        template: _a02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_a02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], A02Page);



/***/ }),

/***/ 1225:
/*!***************************************************!*\
  !*** ./src/app/tab1/a02/a02.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "#mydiv {\n  margin: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImEwMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0YiLCJmaWxlIjoiYTAyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNteWRpdntcclxuICBtYXJnaW46IDIwcHg7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 4394:
/*!***************************************************!*\
  !*** ./src/app/tab1/a02/a02.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/tab1\" text=\"返回\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>a02</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-toolbar>\n    <ion-segment value=\"data\">\n      <ion-segment-button value=\"data\" (click)='click1()'>\n        基本数据类型\n      </ion-segment-button>\n      <ion-segment-button value=\"array\" (click)='click2()'>\n        数组\n      </ion-segment-button>\n      <ion-segment-button value=\"turple\" (click)='click3()'>\n        元组\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n  <div id='mydiv'></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_a02_a02_module_ts.js.map