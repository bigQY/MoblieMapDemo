"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d04_d04_module_ts"],{

/***/ 6636:
/*!************************************************!*\
  !*** ./src/app/tab4/d04/d04-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D04PageRoutingModule": () => (/* binding */ D04PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d04_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d04.page */ 1161);




const routes = [
    {
        path: '',
        component: _d04_page__WEBPACK_IMPORTED_MODULE_0__.D04Page
    }
];
let D04PageRoutingModule = class D04PageRoutingModule {
};
D04PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D04PageRoutingModule);



/***/ }),

/***/ 4951:
/*!****************************************!*\
  !*** ./src/app/tab4/d04/d04.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D04PageModule": () => (/* binding */ D04PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d04_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d04-routing.module */ 6636);
/* harmony import */ var _d04_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d04.page */ 1161);







let D04PageModule = class D04PageModule {
};
D04PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d04_routing_module__WEBPACK_IMPORTED_MODULE_0__.D04PageRoutingModule
        ],
        declarations: [_d04_page__WEBPACK_IMPORTED_MODULE_1__.D04Page]
    })
], D04PageModule);



/***/ }),

/***/ 1161:
/*!**************************************!*\
  !*** ./src/app/tab4/d04/d04.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D04Page": () => (/* binding */ D04Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d04.page.html?ngResource */ 8923);
/* harmony import */ var _d04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d04.page.scss?ngResource */ 1898);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D04Page = class D04Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
    //文字标注
    click1() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.400244, 39.92556);
        map.centerAndZoom(point, 12);
        let marker = new BMap.Marker(point); // 创建标注
        map.addOverlay(marker); // 将标注添加到地图中
        let label = new BMap.Label("我是文字标注哦", { offset: new BMap.Size(20, -10) });
        marker.setLabel(label);
    }
    //动画标注
    click2() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.404, 39.915);
        map.centerAndZoom(point, 15);
        let marker = new BMap.Marker(point); // 创建标注
        map.addOverlay(marker); // 将标注添加到地图中
        marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
    }
    //点标注
    click3() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.404, 39.915);
        map.centerAndZoom(point, 15);
        //创建点
        let marker = new BMap.Marker(new BMap.Point(116.404, 39.915));
        map.addOverlay(marker);
    }
    //多点标注
    click4() {
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 11);
        // 编写自定义函数,创建标注
        let addMarker = (point) => {
            let marker = new BMap.Marker(point);
            map.addOverlay(marker);
        };
        // 随机向地图添加n个标注
        let n = 25;
        let bounds = map.getBounds();
        let sw = bounds.getSouthWest();
        let ne = bounds.getNorthEast();
        let lngSpan = Math.abs(sw.lng - ne.lng);
        let latSpan = Math.abs(ne.lat - sw.lat);
        for (let i = 0; i < n; i++) {
            let point = new BMap.Point(sw.lng + lngSpan * (Math.random() * 0.7), ne.lat - latSpan * (Math.random() * 0.7));
            addMarker(point);
        }
    }
    /**
     * 随机向地图添加n个点标注
     * @param n 要添加的点的个数
     * @returns 添加点标注后的地图
     */
    addLabelMarkers(n) {
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.404, 39.915), 11);
        map.disableDoubleClickZoom();
        map.clearOverlays();
        // 编写自定义函数,创建标注
        let addMarker = (point, label) => {
            let marker = new BMap.Marker(point);
            map.addOverlay(marker);
            marker.setLabel(label);
        };
        // 随机向地图添加n个标注
        let bounds = map.getBounds();
        let sw = bounds.getSouthWest();
        let ne = bounds.getNorthEast();
        let lngSpan = Math.abs(sw.lng - ne.lng);
        let latSpan = Math.abs(ne.lat - sw.lat);
        for (let i = 0; i < n; i++) {
            let point = new BMap.Point(sw.lng + lngSpan * (Math.random() * 0.7), ne.lat - latSpan * (Math.random() * 0.7));
            let label = new BMap.Label("我是id=" + i, { offset: new BMap.Size(20, -10) });
            addMarker(point, label);
        }
        this.map = map;
    }
    //添加多点文字标注
    click5() {
        //随机向地图添加5个Label点标注
        this.addLabelMarkers(5);
    }
    //从添加的多个Label点标注中删除某标注（简单示例）
    click6() {
        //删除"我是id=1"的点
        let allOverlay = this.map.getOverlays();
        for (let i = 0; i < allOverlay.length - 1; i++) {
            let marker = allOverlay[i];
            if (marker) {
                if (marker.getLabel().content == "我是id=1") {
                    this.map.removeOverlay(marker);
                }
            }
        }
    }
};
D04Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
D04Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d04',
        template: _d04_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d04_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D04Page);



/***/ }),

/***/ 1898:
/*!***************************************************!*\
  !*** ./src/app/tab4/d04/d04.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 8923:
/*!***************************************************!*\
  !*** ./src/app/tab4/d04/d04.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D04】标注</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div  style=\"position: fixed;z-index: 99999;\">\n        <ion-button size=\"small\" (click)='click1()'>文字标注</ion-button>\n        <ion-button size=\"small\" (click)='click2()'>动画标注</ion-button>\n        <ion-button size=\"small\" (click)='click3()'>点标注</ion-button>\n        <ion-button size=\"small\" (click)='click4()'>多点标注</ion-button>\n    </div>\n    <div style='top:75px;position: fixed;z-index: 99999;'>\n        <ion-button size=\"small\" (click)='click5()'>添加多点文字标注</ion-button>\n        <ion-button size=\"small\" (click)='click6()'>删除id为1的文字标注</ion-button>\n    </div>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d04_d04_module_ts.js.map