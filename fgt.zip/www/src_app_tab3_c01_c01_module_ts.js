"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_c01_c01_module_ts"],{

/***/ 3966:
/*!************************************************!*\
  !*** ./src/app/tab3/c01/c01-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C01PageRoutingModule": () => (/* binding */ C01PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _c01_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c01.page */ 1381);




const routes = [
    {
        path: '',
        component: _c01_page__WEBPACK_IMPORTED_MODULE_0__.C01Page
    }
];
let C01PageRoutingModule = class C01PageRoutingModule {
};
C01PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], C01PageRoutingModule);



/***/ }),

/***/ 5161:
/*!****************************************!*\
  !*** ./src/app/tab3/c01/c01.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C01PageModule": () => (/* binding */ C01PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _c01_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c01-routing.module */ 3966);
/* harmony import */ var _c01_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c01.page */ 1381);







let C01PageModule = class C01PageModule {
};
C01PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c01_routing_module__WEBPACK_IMPORTED_MODULE_0__.C01PageRoutingModule
        ],
        declarations: [_c01_page__WEBPACK_IMPORTED_MODULE_1__.C01Page]
    })
], C01PageModule);



/***/ }),

/***/ 1381:
/*!**************************************!*\
  !*** ./src/app/tab3/c01/c01.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C01Page": () => (/* binding */ C01Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _c01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c01.page.html?ngResource */ 4037);
/* harmony import */ var _c01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c01.page.scss?ngResource */ 6172);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let C01Page = class C01Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        /** 控制checkbox1的checked属性 */
        this.check1 = false;
        /** 控制checkbox2的checked属性 */
        this.check2 = true;
        /** 控制checkbox3的disabled属性 */
        this.check3Disable = true;
        /** radio按钮组选择的结果 */
        this.r = '篮球';
        /** 下拉框选择的结果 */
        this.gaming = "game1";
    }
    ngOnInit() {
    }
    ionViewDidLoad() {
    }
    showResult() {
        //由于是双向绑定，所以代码中不需要考虑如何与html页面交互，直接使用check1、check2的值就行了
        this.result = `
    复选结果：喜欢篮球：${this.check1}，喜欢排球：${this.check2}
    <br>单选结果：${this.r}
    <br>下拉框选择的结果：${this.gaming}`;
    }
};
C01Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
C01Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-c01',
        template: _c01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_c01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], C01Page);



/***/ }),

/***/ 6172:
/*!***************************************************!*\
  !*** ./src/app/tab3/c01/c01.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjMDEucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4037:
/*!***************************************************!*\
  !*** ./src/app/tab3/c01/c01.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button  text=\"返回\" defaultHref=\"tabs/tab3\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>【C01】基本控件</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n\n<ion-content padding>\n  <ion-button>按钮1</ion-button>\n  <ion-button ion-button round>按钮2</ion-button>\n  <ion-button ion-button>\n    <ion-icon name=\"home\"></ion-icon>\n    按钮3\n    </ion-button>\n    <ion-button ion-button icon-only>\n      <ion-icon name=\"home\"></ion-icon>\n    </ion-button>\n\n    <ion-list style=\"padding:0;margin:0;\">\n      <ion-list-header>\n        请选择你喜欢的体育项目（可多选）:\n      </ion-list-header>\n      <ion-item>\n        <ion-label>篮球</ion-label>\n        <ion-checkbox [(ngModel)]='check1' (ngModelChange)='showResult()'></ion-checkbox>\n      </ion-item>\n      <ion-item>\n        <ion-label>排球</ion-label>\n        <ion-checkbox [(ngModel)]='check2' (ngModelChange)='showResult()'></ion-checkbox>\n      </ion-item>\n    </ion-list>\n    <ion-radio-group radio-group [(ngModel)]=\"r\" (ngModelChange)='showResult()'>\n      <ion-list style=\"padding:0;margin:0;\" >\n        <ion-list-header>\n          你参加的项目是（必须选一项）:\n        </ion-list-header>\n        <ion-item>\n          <ion-label>篮球</ion-label>\n          <ion-radio value=\"篮球\"></ion-radio>\n        </ion-item>\n        <ion-item>\n          <ion-label>排球</ion-label>\n          <ion-radio value=\"排球\"></ion-radio>\n        </ion-item>\n      </ion-list>\n    </ion-radio-group>\n    <ion-list>\n      <ion-item>\n        <ion-label>游戏</ion-label>\n        <ion-select [(ngModel)]=\"gaming\" interface=\"popover\" (ngModelChange)='showResult()'>\n          <ion-select-option value=\"game1\">游戏1</ion-select-option>\n          <ion-select-option value=\"game2\">游戏2</ion-select-option>\n          <ion-select-option value=\"游戏3\">游戏3</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-list>\n\n    <div style=\"border:1px;\" [innerHTML]='result'></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_c01_c01_module_ts.js.map