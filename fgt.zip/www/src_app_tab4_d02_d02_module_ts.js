"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d02_d02_module_ts"],{

/***/ 971:
/*!************************************************!*\
  !*** ./src/app/tab4/d02/d02-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D02PageRoutingModule": () => (/* binding */ D02PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d02_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d02.page */ 4512);




const routes = [
    {
        path: '',
        component: _d02_page__WEBPACK_IMPORTED_MODULE_0__.D02Page
    }
];
let D02PageRoutingModule = class D02PageRoutingModule {
};
D02PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D02PageRoutingModule);



/***/ }),

/***/ 5374:
/*!****************************************!*\
  !*** ./src/app/tab4/d02/d02.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D02PageModule": () => (/* binding */ D02PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d02_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d02-routing.module */ 971);
/* harmony import */ var _d02_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d02.page */ 4512);







let D02PageModule = class D02PageModule {
};
D02PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d02_routing_module__WEBPACK_IMPORTED_MODULE_0__.D02PageRoutingModule
        ],
        declarations: [_d02_page__WEBPACK_IMPORTED_MODULE_1__.D02Page]
    })
], D02PageModule);



/***/ }),

/***/ 4512:
/*!**************************************!*\
  !*** ./src/app/tab4/d02/d02.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D02Page": () => (/* binding */ D02Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d02.page.html?ngResource */ 1901);
/* harmony import */ var _d02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d02.page.scss?ngResource */ 7525);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D02Page = class D02Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ionViewDidLoad() {
        this.map = new BMap.Map("container");
        this.map.centerAndZoom(new BMap.Point(116.404, 39.915), 13);
        this.map.enableScrollWheelZoom();
    }
    //添加折线
    click1() {
        //添加折线
        let x = 116.399; //经度
        let y = 39.950; //纬度（值越大越靠上）
        let polyline1 = new BMap.Polyline([
            new BMap.Point(x, y),
            new BMap.Point(x + 0.006, y + 0.010),
            new BMap.Point(x + 0.026, y - 0.010)
        ], {
            strokeColor: "blue",
            strokeWeight: 2,
            strokeOpacity: 0.5
        });
        this.map.addOverlay(polyline1);
    }
    //添加带箭头的折线
    click2() {
        let x = 116.350658; //经度
        let y = 39.948285; //纬度（值越大越靠上）
        let points = [
            new BMap.Point(x, y),
            new BMap.Point(x + 0.035788, y + 0.000996),
            new BMap.Point(x + 0.038376, y - 0.024457),
            new BMap.Point(x + 0.091843, y - 0.023682)
        ];
        let symbol = new BMap.Symbol(BMap_Symbol_SHAPE_BACKWARD_OPEN_ARROW, {
            scale: 0.6,
            strokeColor: '#fff',
            strokeWeight: 2, //设置线宽
        });
        let iconSequence1 = new BMap.IconSequence(symbol, '10', '30');
        let polyline2 = new BMap.Polyline(points, {
            enableEditing: false,
            enableClicking: true,
            icons: [iconSequence1],
            strokeWeight: 8,
            strokeOpacity: 0.8,
            strokeColor: "#18a45b" //折线颜色
        });
        this.map.addOverlay(polyline2);
    }
    //添加圆
    click3() {
        let circle = new BMap.Circle(new BMap.Point(116.404, 39.925), 500, {
            strokeColor: "blue", strokeWeight: 2, strokeOpacity: 0.5
        });
        this.map.addOverlay(circle);
    }
    //添加多边形
    click4() {
        let polygon = new BMap.Polygon([
            new BMap.Point(116.387112, 39.920977),
            new BMap.Point(116.385243, 39.913063),
            new BMap.Point(116.394226, 39.917988),
            new BMap.Point(116.401772, 39.921364),
            new BMap.Point(116.41248, 39.927893)
        ], { strokeColor: "blue", strokeWeight: 2, strokeOpacity: 0.5 });
        this.map.addOverlay(polygon);
    }
    //添加矩形
    click5() {
        let pStart = new BMap.Point(116.392214, 39.918985);
        let pEnd = new BMap.Point(116.41478, 39.911901);
        let rectangle = new BMap.Polygon([
            new BMap.Point(pStart.lng, pStart.lat),
            new BMap.Point(pEnd.lng, pStart.lat),
            new BMap.Point(pEnd.lng, pEnd.lat),
            new BMap.Point(pStart.lng, pEnd.lat)
        ], { strokeColor: "blue", strokeWeight: 2, strokeOpacity: 0.5 });
        this.map.addOverlay(rectangle);
    }
    //删除所有覆盖物
    deleteClick() {
        this.map.clearOverlays();
    }
    ngOnInit() {
        this.ionViewDidLoad();
    }
};
D02Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
D02Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d02',
        template: _d02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D02Page);



/***/ }),

/***/ 7525:
/*!***************************************************!*\
  !*** ./src/app/tab4/d02/d02.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDIucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 1901:
/*!***************************************************!*\
  !*** ./src/app/tab4/d02/d02.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n      <ion-buttons slot=\"start\">\n          <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n      </ion-buttons>\n      <ion-title>【D02】覆盖物</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div  style=\"position: fixed;z-index: 99999;\">\n      <label>添加：</label>\n      <ion-button size=\"small\" (click)='click1()'>折线</ion-button>\n      <ion-button size=\"small\" (click)='click2()'>箭头折线</ion-button>\n      <ion-button size=\"small\" (click)='click3()'>圆</ion-button>\n      <ion-button size=\"small\" (click)='click4()'>多边形</ion-button>\n      <ion-button size=\"small\" (click)='click5()'>矩形</ion-button>\n      <br>\n      <label>删除：</label>\n      <ion-button size=\"small\" (click)='deleteClick()'>清除所有覆盖物</ion-button>\n  </div>\n  <div id=\"container\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d02_d02_module_ts.js.map