"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_b03_b03_module_ts"],{

/***/ 8197:
/*!************************************************!*\
  !*** ./src/app/tab2/b03/b03-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B03PageRoutingModule": () => (/* binding */ B03PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _b03_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b03.page */ 2755);




const routes = [
    {
        path: '',
        component: _b03_page__WEBPACK_IMPORTED_MODULE_0__.B03Page
    }
];
let B03PageRoutingModule = class B03PageRoutingModule {
};
B03PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], B03PageRoutingModule);



/***/ }),

/***/ 4509:
/*!****************************************!*\
  !*** ./src/app/tab2/b03/b03.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B03PageModule": () => (/* binding */ B03PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _b03_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b03-routing.module */ 8197);
/* harmony import */ var _b03_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b03.page */ 2755);







let B03PageModule = class B03PageModule {
};
B03PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _b03_routing_module__WEBPACK_IMPORTED_MODULE_0__.B03PageRoutingModule
        ],
        declarations: [_b03_page__WEBPACK_IMPORTED_MODULE_1__.B03Page]
    })
], B03PageModule);



/***/ }),

/***/ 2755:
/*!**************************************!*\
  !*** ./src/app/tab2/b03/b03.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B03Page": () => (/* binding */ B03Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _b03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b03.page.html?ngResource */ 5626);
/* harmony import */ var _b03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b03.page.scss?ngResource */ 3078);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);



/* eslint-disable @typescript-eslint/member-ordering */


let B03Page = class B03Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
    showResult(s) {
        this.result = '你输入的姓名为：' + this.xm + '<br>' +
            '你参加的项目是：' + this.r;
    }
};
B03Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
B03Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-b03',
        template: _b03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_b03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], B03Page);



/***/ }),

/***/ 3078:
/*!***************************************************!*\
  !*** ./src/app/tab2/b03/b03.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiMDMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 5626:
/*!***************************************************!*\
  !*** ./src/app/tab2/b03/b03.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"返回\" defaultHerf=\"tabs/tab2\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>【B03】双向绑定</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content style=\"margin: 10px;\">\n  <ion-item style=\"margin: 10px;width: 90vw;\">\n    <ion-label position=\"floating\">姓名</ion-label>\n    <ion-input [(ngModel)]='xm' (ngModelChange)='showResult()' placeholder=\"请输入姓名\"></ion-input>\n  </ion-item>\n  <div>\n    <ion-list style=\"margin: 10px;width: 90vw;\">\n      <ion-radio-group checked [(ngModel)]=\"r\" (ngModelChange)='showResult()'>\n        <ion-list-header>\n          <ion-label>你参加的项目是（必须选一项）：</ion-label>\n        </ion-list-header>\n\n        <ion-item>\n          <ion-label>唱</ion-label>\n          <ion-radio slot=\"start\" value=\"唱\"></ion-radio>\n        </ion-item>\n\n        <ion-item>\n          <ion-label>跳</ion-label>\n          <ion-radio slot=\"start\" value=\"跳\"></ion-radio>\n        </ion-item>\n\n        <ion-item>\n          <ion-label>RAP</ion-label>\n          <ion-radio slot=\"start\" value=\"RAP\"></ion-radio>\n        </ion-item>\n\n        <ion-item>\n          <ion-label>篮球</ion-label>\n          <ion-radio slot=\"start\" value=\"篮球\"></ion-radio>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n  </div>\n  <br>\n  <br>\n  <div [innerHTML]='result' style=\"margin: 10px;width: 90vw;\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_b03_b03_module_ts.js.map