"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_b01_b01_module_ts"],{

/***/ 9382:
/*!************************************************!*\
  !*** ./src/app/tab2/b01/b01-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B01PageRoutingModule": () => (/* binding */ B01PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _b01_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b01.page */ 1197);




const routes = [
    {
        path: '',
        component: _b01_page__WEBPACK_IMPORTED_MODULE_0__.B01Page
    }
];
let B01PageRoutingModule = class B01PageRoutingModule {
};
B01PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], B01PageRoutingModule);



/***/ }),

/***/ 9357:
/*!****************************************!*\
  !*** ./src/app/tab2/b01/b01.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B01PageModule": () => (/* binding */ B01PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _b01_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b01-routing.module */ 9382);
/* harmony import */ var _b01_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b01.page */ 1197);







let B01PageModule = class B01PageModule {
};
B01PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _b01_routing_module__WEBPACK_IMPORTED_MODULE_0__.B01PageRoutingModule
        ],
        declarations: [_b01_page__WEBPACK_IMPORTED_MODULE_1__.B01Page]
    })
], B01PageModule);



/***/ }),

/***/ 1197:
/*!**************************************!*\
  !*** ./src/app/tab2/b01/b01.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B01Page": () => (/* binding */ B01Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _b01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./b01.page.html?ngResource */ 4437);
/* harmony import */ var _b01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./b01.page.scss?ngResource */ 3969);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);



/* eslint-disable @angular-eslint/use-lifecycle-interface */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/type-annotation-spacing */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/quotes */
/* eslint-disable @typescript-eslint/member-ordering */


let B01Page = class B01Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ionViewDidLoad() {
        setInterval(() => {
            this.current = this.DateFormat(Date.now(), 'yyyy-MM-dd hh:mm:ss');
        }, 1000);
    }
    // 为什么给的示例总是缺少这个函数，裂开了
    ngOnInit() {
        this.ionViewDidLoad();
    }
    DateFormat(n, format) {
        let date = new Date(n);
        let y = date.getFullYear().toString();
        let month = date.getMonth() + 1;
        let MM = month < 10 ? '0' + month : '' + month;
        let d = date.getDate();
        let DD = d < 10 ? '0' + d : '' + d;
        let h = date.getHours();
        let HH = h < 10 ? '0' + h : '' + h;
        let m = date.getMinutes();
        let mm = m < 10 ? '0' + m : '' + m;
        let s = date.getSeconds();
        let ss = s < 10 ? '0' + s : '' + s;
        let newdate;
        newdate = format.replace('yyyy', y);
        newdate = newdate.replace('MM', MM);
        newdate = newdate.replace('dd', DD);
        newdate = newdate.replace('hh', HH);
        newdate = newdate.replace('mm', mm);
        newdate = newdate.replace('ss', ss);
        return newdate;
    }
};
B01Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
B01Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-b01',
        template: _b01_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_b01_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], B01Page);



/***/ }),

/***/ 3969:
/*!***************************************************!*\
  !*** ./src/app/tab2/b01/b01.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJiMDEucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4437:
/*!***************************************************!*\
  !*** ./src/app/tab2/b01/b01.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHerf=\"tabs/tab2\" text=\"返回\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>b01</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- <div><button (click) = 'click1'>1-1 xxxx</button></div>\n  <br>\n  <div><button (click) = 'click1'>1-2 xxxx</button></div>\n  <br>\n  <div id=\"mydiv\"></div> -->\n  <div class=\"mydiv\" style=\"margin: 20px;\">\n    <p>\n      显示系统时间：\n      <br>\n      {{current}}\n    </p>\n    <p style=\"font-size: 14px;\">\n      Angular是一种以【组件】为中心的架构，而不是以HTML为中心。\n    </p>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_b01_b01_module_ts.js.map