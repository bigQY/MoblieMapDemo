"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab4_d06_d06_module_ts"],{

/***/ 7230:
/*!************************************************!*\
  !*** ./src/app/tab4/d06/d06-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D06PageRoutingModule": () => (/* binding */ D06PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _d06_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d06.page */ 6809);




const routes = [
    {
        path: '',
        component: _d06_page__WEBPACK_IMPORTED_MODULE_0__.D06Page
    }
];
let D06PageRoutingModule = class D06PageRoutingModule {
};
D06PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], D06PageRoutingModule);



/***/ }),

/***/ 8415:
/*!****************************************!*\
  !*** ./src/app/tab4/d06/d06.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D06PageModule": () => (/* binding */ D06PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _d06_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d06-routing.module */ 7230);
/* harmony import */ var _d06_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d06.page */ 6809);







let D06PageModule = class D06PageModule {
};
D06PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _d06_routing_module__WEBPACK_IMPORTED_MODULE_0__.D06PageRoutingModule
        ],
        declarations: [_d06_page__WEBPACK_IMPORTED_MODULE_1__.D06Page]
    })
], D06PageModule);



/***/ }),

/***/ 6809:
/*!**************************************!*\
  !*** ./src/app/tab4/d06/d06.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D06Page": () => (/* binding */ D06Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _d06_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./d06.page.html?ngResource */ 8746);
/* harmony import */ var _d06_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./d06.page.scss?ngResource */ 9269);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1864);





let D06Page = class D06Page {
    constructor(alertCtrl, navCtrl) {
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
    }
    showAlert(_message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            (yield (this.alertCtrl.create({
                header: _message,
                buttons: ['确定']
            }))).present();
        });
    }
    ngOnInit() {
    }
    //浏览器定位
    click1() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.331398, 39.897445);
        map.centerAndZoom(point, 12);
        let geolocation = new BMap.Geolocation();
        geolocation.getCurrentPosition((r) => {
            if (geolocation.getStatus() == BMAP_STATUS_SUCCESS) {
                let mk = new BMap.Marker(r.point);
                map.addOverlay(mk);
                map.panTo(r.point);
                this.showAlert('您的位置：' + r.point.lng + ',' + r.point.lat);
            }
            else {
                this.showAlert('failed' + geolocation.getStatus());
            }
        }, { enableHighAccuracy: true });
    }
    //根据ip定位【获取当前城市】
    click2() {
        let map = new BMap.Map("bdmap");
        let point = new BMap.Point(116.331398, 39.897445);
        map.centerAndZoom(point, 12);
        let myFun = (result) => {
            let cityName = result.name;
            map.setCenter(cityName);
            this.showAlert("当前定位城市:" + cityName);
        };
        let myCity = new BMap.LocalCity();
        myCity.get(myFun);
    }
    //根据城市名定位
    click3() {
        let myGeo = new BMap.Geocoder();
        let city = "开封市";
        myGeo.getPoint(city, (p) => {
            let map = new BMap.Map("bdmap");
            if (p) {
                map.centerAndZoom(p, 11); // 用城市名设置地图中心点
            }
            else {
                ///定位失败，显示北京市地图
                let point = new BMap.Point(116.331398, 39.897445);
                map.centerAndZoom(point, 11); // 用城市名设置地图中心点
            }
        }, city);
    }
    //根据经纬度定位城市
    click4() {
        let map = new BMap.Map("bdmap");
        map.centerAndZoom(new BMap.Point(116.331398, 39.897445), 11);
        map.enableScrollWheelZoom();
        // 用经纬度设置地图中心点
        let MyLocation = (longitude, latitude) => {
            map.clearOverlays();
            let p = new BMap.Point(longitude, latitude);
            let marker = new BMap.Marker(p); // 创建标注
            map.addOverlay(marker); // 将标注添加到地图中
            map.panTo(p);
        };
        //重新定位中心点到河南大学
        MyLocation(114.315745, 34.824635);
    }
};
D06Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
D06Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-d06',
        template: _d06_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_d06_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], D06Page);



/***/ }),

/***/ 9269:
/*!***************************************************!*\
  !*** ./src/app/tab4/d06/d06.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkMDYucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 8746:
/*!***************************************************!*\
  !*** ./src/app/tab4/d06/d06.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab4\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【D06】定位</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <div  style=\"position: fixed;z-index: 99999;\">\n        <ion-button size=\"small\" (click)='click1()'>浏览器定位</ion-button>\n        <ion-button size=\"small\" (click)='click2()'>ip定位</ion-button>\n        <ion-button size=\"small\" (click)='click3()'>城市名定位</ion-button>\n        <ion-button size=\"small\" (click)='click4()'>经纬度定位</ion-button>\n    </div>\n    <div id=\"bdmap\" style=\"height: 100%; width: 100%\"></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab4_d06_d06_module_ts.js.map