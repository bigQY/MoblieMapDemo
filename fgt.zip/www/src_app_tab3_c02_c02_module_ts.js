"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_c02_c02_module_ts"],{

/***/ 1594:
/*!************************************************!*\
  !*** ./src/app/tab3/c02/c02-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C02PageRoutingModule": () => (/* binding */ C02PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _c02_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c02.page */ 7227);




const routes = [
    {
        path: '',
        component: _c02_page__WEBPACK_IMPORTED_MODULE_0__.C02Page
    }
];
let C02PageRoutingModule = class C02PageRoutingModule {
};
C02PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], C02PageRoutingModule);



/***/ }),

/***/ 1738:
/*!****************************************!*\
  !*** ./src/app/tab3/c02/c02.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C02PageModule": () => (/* binding */ C02PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _c02_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c02-routing.module */ 1594);
/* harmony import */ var _c02_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c02.page */ 7227);







let C02PageModule = class C02PageModule {
};
C02PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c02_routing_module__WEBPACK_IMPORTED_MODULE_0__.C02PageRoutingModule
        ],
        declarations: [_c02_page__WEBPACK_IMPORTED_MODULE_1__.C02Page]
    })
], C02PageModule);



/***/ }),

/***/ 7227:
/*!**************************************!*\
  !*** ./src/app/tab3/c02/c02.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C02Page": () => (/* binding */ C02Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _c02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c02.page.html?ngResource */ 2672);
/* harmony import */ var _c02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c02.page.scss?ngResource */ 8704);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1864);





let C02Page = class C02Page {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.gender = "f";
        this.gaming = "n64";
        this.musicAlertOpts = {
            header: '1994 Music',
            subHeader: '请选择你喜欢的'
        };
    }
    stpSelect() {
        console.log('STP selected');
    }
    ngOnInit() {
    }
};
C02Page.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
C02Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-c02',
        template: _c02_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_c02_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], C02Page);



/***/ }),

/***/ 8704:
/*!***************************************************!*\
  !*** ./src/app/tab3/c02/c02.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjMDIucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 2672:
/*!***************************************************!*\
  !*** ./src/app/tab3/c02/c02.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab3\" text=\"返回\"></ion-back-button>\n        </ion-buttons>\n        <ion-title>【C02】下拉框</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding>\n    <ion-list>\n        <ion-item>\n            <ion-label>性别</ion-label>\n            <ion-select [(ngModel)]=\"gender\" interface=\"popover\">\n                <ion-select-option value=\"f\">女</ion-select-option>\n                <ion-select-option value=\"m\">男</ion-select-option>\n            </ion-select>\n        </ion-item>\n        <ion-item>\n            <ion-label>游戏</ion-label>\n            <ion-select [(ngModel)]=\"gaming\" interface=\"popover\">\n                <ion-select-option value=\"nes\">NES游戏</ion-select-option>\n                <ion-select-option value=\"n64\">N64游戏</ion-select-option>\n                <ion-select-option value=\"ps\">PS游戏</ion-select-option>\n            </ion-select>\n        </ion-item>\n        <ion-item>\n            <ion-label>日期</ion-label>\n            <ion-select [(ngModel)]=\"month\" interface=\"popover\">\n                <ion-select-option value=\"o1\">January</ion-select-option>\n                <ion-select-option value=\"02\">February</ion-select-option>\n                <ion-select-option value=\"03\">March</ion-select-option>\n                <ion-select-option value=\"04\">April</ion-select-option>\n                <ion-select-option value=\"05\">May</ion-select-option>\n                <ion-select-option value=\"06\">June</ion-select-option>\n                <ion-select-option value=\"07\">July</ion-select-option>\n                <ion-select-option value=\"08\">August</ion-select-option>\n                <ion-select-option value=\"09\">September</ion-select-option>\n                <ion-select-option value=\"10\">October</ion-select-option>\n                <ion-select-option value=\"1l\">November</ion-select-option>\n                <ion-select-option value=\"12\" checked=\"true\">December</ion-select-option>\n            </ion-select>\n            <ion-select [(ngModel)]=\"year\" interface=\"popover\">\n                <ion-select-option>2018</ion-select-option>\n                <ion-select-option checked=\"true\">2019</ion-select-option>\n                <ion-select-option>2020</ion-select-option>\n                <ion-select-option>2021</ion-select-option>\n            </ion-select>\n        </ion-item>\n        <ion-item>\n            <ion-label>音乐</ion-label>\n            <ion-select [(ngModel)]=\"music\" [interfaceOptions]=\"musicAlertOpts\">\n                <ion-select-option>音乐1</ion-select-option>\n                <ion-select-option>音乐2</ion-select-option>\n                <ion-select-option (select)=\"stpSelect()\">音乐3</ion-select-option>\n            </ion-select>\n        </ion-item>\n    </ion-list>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_c02_c02_module_ts.js.map