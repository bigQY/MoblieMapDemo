"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_a03_a03_module_ts"],{

/***/ 9915:
/*!************************************************!*\
  !*** ./src/app/tab1/a03/a03-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A03PageRoutingModule": () => (/* binding */ A03PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3903);
/* harmony import */ var _a03_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a03.page */ 5865);




const routes = [
    {
        path: '',
        component: _a03_page__WEBPACK_IMPORTED_MODULE_0__.A03Page
    }
];
let A03PageRoutingModule = class A03PageRoutingModule {
};
A03PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], A03PageRoutingModule);



/***/ }),

/***/ 9223:
/*!****************************************!*\
  !*** ./src/app/tab1/a03/a03.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A03PageModule": () => (/* binding */ A03PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8750);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 6410);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _a03_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a03-routing.module */ 9915);
/* harmony import */ var _a03_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a03.page */ 5865);







let A03PageModule = class A03PageModule {
};
A03PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _a03_routing_module__WEBPACK_IMPORTED_MODULE_0__.A03PageRoutingModule
        ],
        declarations: [_a03_page__WEBPACK_IMPORTED_MODULE_1__.A03Page]
    })
], A03PageModule);



/***/ }),

/***/ 5865:
/*!**************************************!*\
  !*** ./src/app/tab1/a03/a03.page.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A03Page": () => (/* binding */ A03Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _a03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./a03.page.html?ngResource */ 4934);
/* harmony import */ var _a03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./a03.page.scss?ngResource */ 1805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 8259);




let A03Page = class A03Page {
    constructor() {
    }
    ngOnInit() {
        this.myDiv = document.getElementById('mydiv');
        this.myDiv.innerText = '此处显示单击按钮后输出的结果';
        this.click1();
    }
    //1、字符串字面量类型【x: 'a' | 'b' | 'c' | 'd'】
    click1() {
        class MyClass {
            constructor(opts) {
                this.opts = opts;
            }
        }
        const options = {
            a: 3,
            b: 'ease-in'
        };
        const c = new MyClass(options);
        this.myDiv.innerHTML = `1、字符串字面量类型<hr/>
        <p>
            a的options属性的值为：<br/>
            x=${c.opts.a}，b=${c.opts.b}
        </p>`;
    }
    //2、联合【a | b | c | d】（注意观察和1的区别在哪）
    click2() {
        this.myDiv.innerHTML = '2、联合<hr/>';
        const opts = {
            p1: '',
            p2: '',
        };
        opts.p1 = 'hello world'; // OK
        opts.p2 = ['a1', 'a2']; // OK
        this.myDiv.innerHTML += `<p>
            opts的值为：<br/>
            p1：${opts.p1}<br/>
            p2：${opts.p2[0]}，${opts.p2[1]}
        </p>`;
    }
    //交叉【a & b & c & d】（难点）
    click3() {
        this.myDiv.innerHTML = '3、交叉<hr/>';
        function MyExt(first, second) {
            const result = {};
            for (const id in first) {
                result[id] = first[id];
            }
            for (const id in second) {
                if (!result.hasOwnProperty(id)) {
                    result[id] = second[id];
                }
            }
            return result;
        }
        class Person {
            constructor(name) {
                this.name = name;
            }
        }
        class ConsoleLogger {
            log() {
                console.log('hello!');
            }
        }
        const jim = MyExt(new Person('杰姆'), new ConsoleLogger());
        console.log(jim);
        this.myDiv.innerHTML += `<p>
            jim的name属性值为：${jim.name}<br/>
        </p>`;
    }
};
A03Page.ctorParameters = () => [];
A03Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-a03',
        template: _a03_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_a03_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], A03Page);



/***/ }),

/***/ 1805:
/*!***************************************************!*\
  !*** ./src/app/tab1/a03/a03.page.scss?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "page-a03 #mydiv {\n  border: 1px solid red;\n  margin: 10 0 0 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImEwMy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDSSxxQkFBQTtFQUNBLGdCQUFBO0FBQU4iLCJmaWxlIjoiYTAzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInBhZ2UtYTAzIHtcclxuICAjbXlkaXYge1xyXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCByZWQ7XHJcbiAgICAgIG1hcmdpbjogMTAgMCAwIDA7IC8v5LiK44CB5Y+z44CB5LiL44CB5bemXHJcbiAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 4934:
/*!***************************************************!*\
  !*** ./src/app/tab1/a03/a03.page.html?ngResource ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"tabs/tab1\" text=\"返回\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>a03</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-toolbar>\n    <ion-segment value=\"data\">\n      <ion-segment-button value=\"data\" (click)='click1()'>\n        字符串字面量类型\n      </ion-segment-button>\n      <ion-segment-button value=\"array\" (click)='click2()'>\n        联合\n      </ion-segment-button>\n      <ion-segment-button value=\"turple\" (click)='click3()'>\n        交叉\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n    <br/>\n    <div id='mydiv'></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_a03_a03_module_ts.js.map